package com.nowcoder.service;

import com.nowcoder.model.Feed;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * Created by nowcoder on 2016/8/12.
 */
@Service
public class TimelineService {

    public List<Feed> pull(int userId, int maxId, int count) {
        return null;
    }
}
